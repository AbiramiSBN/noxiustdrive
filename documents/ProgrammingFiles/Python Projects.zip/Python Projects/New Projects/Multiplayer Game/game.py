import os
import math
import random
import sys
from dataclasses import dataclass

from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QPushButton, QLabel, QProgressBar, QCheckBox
)
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QPainter, QColor, QPen, QBrush, QFont, QPixmap


# ============================
# CONFIG: 1080p
# ============================
W, H = 1920, 1080
BORDER = 20               # arena border padding
PLAYER_RADIUS = 22
FPS_MS = 16


# ----------------------------
# Data Models
# ----------------------------

@dataclass
class Weapon:
    key: str
    name: str
    damage: int
    range: float
    speed: float
    cost: int
    icon: str
    kind: str             # "melee" or "ranged"
    proj_speed: float = 0.0
    proj_radius: float = 0.0
    proj_life: int = 0
    spread: float = 0.0


@dataclass
class Projectile:
    x: float
    y: float
    vx: float
    vy: float
    dmg: int
    radius: float
    owner: int       # 1 or 2
    life: int


@dataclass
class Pickup:
    x: float
    y: float
    kind: str        # "coin" | "potion" | "weapon"
    value: int = 0
    weapon_key: str = ""
    radius: float = 14.0


@dataclass
class Particle:
    x: float
    y: float
    vx: float
    vy: float
    life: int
    size: float
    color: QColor


class Player:
    def __init__(self, x, y, color, controls, pid):
        self.x = float(x)
        self.y = float(y)
        self.health = 100
        self.coins = 0

        self.weapon = "sword"
        self.direction = 1

        self.attacking = False
        self.attack_timer = 0
        self.attack_duration = 0
        self.cooldown_timer = 0

        self.hit_flash = 0
        self.color = color
        self.controls = controls
        self.pid = pid


# ----------------------------
# Canvas
# ----------------------------

class GameCanvas(QWidget):
    def __init__(self, parent):
        super().__init__(parent)
        self.g = parent
        self.setMinimumSize(W, H)

    def paintEvent(self, event):
        g = self.g
        if g.state != "game":
            return

        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)

        sx, sy = g.shake_offset()

        # Background - fills entire canvas
        if g.bg_pixmap and not g.bg_pixmap.isNull():
            painter.drawPixmap(int(sx), int(sy), W, H, g.bg_pixmap)
        else:
            painter.fillRect(int(sx), int(sy), W, H, QColor(10, 16, 28))
            # optional grid
            pen = QPen(QColor(30, 40, 70))
            painter.setPen(pen)
            step = 60
            for i in range(0, W, step):
                painter.drawLine(int(sx) + i, int(sy), int(sx) + i, int(sy) + H)
            for i in range(0, H, step):
                painter.drawLine(int(sx), int(sy) + i, int(sx) + W, int(sy) + i)

        # Arena border
        painter.setPen(QPen(QColor(160, 160, 200), 3))
        painter.drawRect(int(sx) + BORDER, int(sy) + BORDER, W - 2 * BORDER, H - 2 * BORDER)

        # Pickups
        for pu in g.pickups:
            if pu.kind == "coin":
                painter.setBrush(QBrush(QColor(251, 191, 36)))
                painter.setPen(Qt.PenStyle.NoPen)
                painter.drawEllipse(int(sx + pu.x - pu.radius), int(sy + pu.y - pu.radius),
                                    int(pu.radius * 2), int(pu.radius * 2))
                painter.setPen(QPen(QColor(0, 0, 0)))
                painter.setFont(QFont("Arial", 10, QFont.Weight.Bold))
                painter.drawText(int(sx + pu.x - 5), int(sy + pu.y + 4), "$")

            elif pu.kind == "potion":
                painter.setBrush(QBrush(QColor(34, 197, 94)))
                painter.setPen(Qt.PenStyle.NoPen)
                painter.drawRoundedRect(int(sx + pu.x - 10), int(sy + pu.y - 14), 20, 28, 6, 6)
                painter.setPen(QPen(QColor(255, 255, 255), 2))
                painter.drawLine(int(sx + pu.x - 6), int(sy + pu.y), int(sx + pu.x + 6), int(sy + pu.y))
                painter.drawLine(int(sx + pu.x), int(sy + pu.y - 6), int(sx + pu.x), int(sy + pu.y + 6))

            elif pu.kind == "weapon":
                wpn = g.weapons.get(pu.weapon_key)
                painter.setBrush(QBrush(QColor(59, 130, 246)))
                painter.setPen(QPen(QColor(226, 232, 240), 2))
                painter.drawRoundedRect(int(sx + pu.x - 18), int(sy + pu.y - 18), 36, 36, 10, 10)

                painter.setPen(QPen(QColor(15, 23, 42)))
                painter.setFont(QFont("Arial", 13, QFont.Weight.Bold))
                icon = wpn.icon if wpn else "?"
                painter.drawText(int(sx + pu.x - 9), int(sy + pu.y + 6), icon)

                if wpn:
                    painter.setPen(QPen(QColor(226, 232, 240)))
                    painter.setFont(QFont("Arial", 9))
                    painter.drawText(int(sx + pu.x - 30), int(sy + pu.y - 22), wpn.name[:10])

        # Particles
        for p in g.particles:
            alpha = max(0, min(255, int(255 * (p.life / 20))))
            c = QColor(p.color)
            c.setAlpha(alpha)
            painter.setBrush(QBrush(c))
            painter.setPen(Qt.PenStyle.NoPen)
            painter.drawEllipse(int(sx + p.x - p.size), int(sy + p.y - p.size),
                                int(p.size * 2), int(p.size * 2))

        # Projectiles
        for pr in g.projectiles:
            painter.setBrush(QBrush(QColor(147, 197, 253) if pr.owner == 1 else QColor(252, 165, 165)))
            painter.setPen(Qt.PenStyle.NoPen)
            painter.drawEllipse(int(sx + pr.x - pr.radius), int(sy + pr.y - pr.radius),
                                int(pr.radius * 2), int(pr.radius * 2))

        # Players + health bars
        for player in (g.p1, g.p2):
            px, py = player.x, player.y

            spr = g.p1_pixmap if player.pid == 1 else g.p2_pixmap
            if spr and not spr.isNull():
                ww, hh = 64, 64
                painter.drawPixmap(int(sx + px - ww / 2), int(sy + py - hh / 2), ww, hh, spr)
            else:
                painter.setBrush(QBrush(player.color))
                painter.setPen(Qt.PenStyle.NoPen)
                painter.drawEllipse(int(sx + px - PLAYER_RADIUS), int(sy + py - PLAYER_RADIUS),
                                    PLAYER_RADIUS * 2, PLAYER_RADIUS * 2)

            if player.hit_flash > 0:
                painter.setBrush(Qt.BrushStyle.NoBrush)
                painter.setPen(QPen(QColor(255, 255, 255), 3))
                painter.drawEllipse(int(sx + px - 28), int(sy + py - 28), 56, 56)

            painter.setBrush(QBrush(QColor(255, 255, 255)))
            painter.setPen(Qt.PenStyle.NoPen)
            painter.drawEllipse(int(sx + px + player.direction * 12 - 5), int(sy + py - 5), 10, 10)

            self.draw_health_bar(painter, sx + px, sy + py - 55, player.health)

            if player.attacking:
                wpn = g.weapons[player.weapon]
                if wpn.kind == "melee":
                    progress = 1.0 - (player.attack_timer / max(1, player.attack_duration))
                    swing_len = wpn.range * (0.6 + 0.9 * progress)
                    swing_h = 10 + int(14 * progress)
                    alpha = int(220 * (1.0 - progress))
                    c = QColor(251, 191, 36, max(0, alpha))
                    painter.setBrush(QBrush(c))
                    painter.setPen(Qt.PenStyle.NoPen)
                    x0 = px + player.direction * 28
                    y0 = py - swing_h / 2
                    painter.drawRoundedRect(
                        int(sx + x0), int(sy + y0),
                        int(player.direction * swing_len), int(swing_h),
                        6, 6
                    )

        painter.end()

    def draw_health_bar(self, painter: QPainter, cx: float, top_y: float, hp: float):
        bar_w, bar_h = 80, 10
        x = int(cx - bar_w / 2)
        y = int(top_y)

        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(QBrush(QColor(15, 23, 42, 220)))
        painter.drawRoundedRect(x, y, bar_w, bar_h, 5, 5)

        pct = max(0.0, min(1.0, hp / 100.0))
        fill_w = int(bar_w * pct)

        fill_color = QColor(34, 197, 94) if pct > 0.5 else (QColor(251, 191, 36) if pct > 0.2 else QColor(220, 38, 38))
        painter.setBrush(QBrush(fill_color))
        painter.drawRoundedRect(x, y, fill_w, bar_h, 5, 5)

        painter.setBrush(Qt.BrushStyle.NoBrush)
        painter.setPen(QPen(QColor(226, 232, 240, 160), 1))
        painter.drawRoundedRect(x, y, bar_w, bar_h, 5, 5)


# ----------------------------
# Game
# ----------------------------

class BattleArenaGame(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Battle Arena - 1080p Fullscreen")

        self.assets_dir = os.path.join(os.path.dirname(__file__), "assets")
        self.bg_pixmap = self.load_pixmap(os.path.join(self.assets_dir, "bg.png"))
        self.p1_pixmap = self.load_pixmap(os.path.join(self.assets_dir, "p1.png"))
        self.p2_pixmap = self.load_pixmap(os.path.join(self.assets_dir, "p2.png"))

        self.weapons = self.build_weapons()

        self.vs_bot = False
        self.state = "menu"
        self.keys_pressed = set()
        self.ticks = 0

        self.shake = 0
        self.shake_strength = 0

        self.projectiles = []
        self.pickups = []
        self.particles = []

        self.p1 = Player(200, H / 2, QColor(59, 130, 246),
                         {'left': Qt.Key.Key_A, 'right': Qt.Key.Key_D,
                          'up': Qt.Key.Key_W, 'down': Qt.Key.Key_S,
                          'attack': Qt.Key.Key_Space},
                         pid=1)

        self.p2 = Player(W - 200, H / 2, QColor(239, 68, 68),
                         {'left': Qt.Key.Key_Left, 'right': Qt.Key.Key_Right,
                          'up': Qt.Key.Key_Up, 'down': Qt.Key.Key_Down,
                          'attack': Qt.Key.Key_Return},
                         pid=2)

        self.timer_id = self.startTimer(FPS_MS)
        self.init_ui()

        # Fullscreen + 1080p surface
        self.setFixedSize(W, H)
        self.showFullScreen()

    def load_pixmap(self, path: str):
        if os.path.exists(path):
            pm = QPixmap(path)
            if not pm.isNull():
                return pm
        return None

    def build_weapons(self):
        return {
            "sword":   Weapon("sword", "Sword", 15, 60, 0.85, 0,   "⚔️", "melee"),
            "axe":     Weapon("axe", "Battle Axe", 25, 55, 0.65, 100, "🪓", "melee"),
            "spear":   Weapon("spear", "Spear", 12, 95, 0.95, 80,  "🗡️", "melee"),
            "hammer":  Weapon("hammer", "Hammer", 32, 50, 0.55, 150, "🔨", "melee"),
            "dagger":  Weapon("dagger", "Dagger", 9,  40, 1.20, 120, "🗡️", "melee"),
            "katana":  Weapon("katana", "Katana", 18, 70, 1.05, 220, "🗡️", "melee"),

            "bow":     Weapon("bow", "Bow", 10, 22, 0.95, 160, "🏹", "ranged",
                              proj_speed=14.0, proj_radius=6.5, proj_life=95, spread=0.08),
            "crossbow": Weapon("crossbow", "Crossbow", 16, 22, 0.75, 260, "🏹", "ranged",
                               proj_speed=16.0, proj_radius=6.0, proj_life=90, spread=0.03),
            "firestaff": Weapon("firestaff", "Fire Staff", 14, 26, 0.70, 300, "🔥", "ranged",
                                proj_speed=12.0, proj_radius=9.5, proj_life=85, spread=0.06),
            "blaster": Weapon("blaster", "Blaster", 12, 22, 1.05, 340, "🔫", "ranged",
                              proj_speed=18.0, proj_radius=5.5, proj_life=75, spread=0.04),
        }

    # ---------------- UI ----------------
    def init_ui(self):
        self.central_widget = QWidget()
        self.setCentralWidget(self.central_widget)
        self.main_layout = QVBoxLayout(self.central_widget)
        self.show_menu()

    def show_menu(self):
        self.state = "menu"
        self.clear_layout()

        layout = QVBoxLayout()
        layout.setAlignment(Qt.AlignmentFlag.AlignCenter)

        title = QLabel("⚔️ BATTLE ARENA ⚔️")
        title.setStyleSheet("font-size: 54px; font-weight: bold; color: white;")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(title)

        subtitle = QLabel("1080p Fullscreen • Background fills whole screen • Weapon pickups • Health bars")
        subtitle.setStyleSheet("font-size: 16px; color: #cbd5e1;")
        subtitle.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(subtitle)

        layout.addSpacing(20)

        self.bot_checkbox = QCheckBox("Play vs Bot (Player 2 AI)")
        self.bot_checkbox.setChecked(self.vs_bot)
        self.bot_checkbox.setStyleSheet("color:white; font-size:16px;")
        self.bot_checkbox.stateChanged.connect(lambda _: self.set_bot_mode())
        layout.addWidget(self.bot_checkbox, alignment=Qt.AlignmentFlag.AlignCenter)

        layout.addSpacing(24)

        start_btn = QPushButton("▶ Start Battle")
        start_btn.setStyleSheet("""
            QPushButton { background:#16a34a; color:white; font-size:28px; font-weight:bold;
                          padding:18px 50px; border-radius:14px; }
            QPushButton:hover { background:#15803d; }
        """)
        start_btn.clicked.connect(self.start_game)
        layout.addWidget(start_btn, alignment=Qt.AlignmentFlag.AlignCenter)

        shop_btn = QPushButton("🛒 Weapon Shop")
        shop_btn.setStyleSheet("""
            QPushButton { background:#ca8a04; color:white; font-size:28px; font-weight:bold;
                          padding:18px 50px; border-radius:14px; }
            QPushButton:hover { background:#a16207; }
        """)
        shop_btn.clicked.connect(self.show_shop)
        layout.addWidget(shop_btn, alignment=Qt.AlignmentFlag.AlignCenter)

        hint = QLabel("Tip: Press ESC to exit fullscreen anytime.")
        hint.setStyleSheet("color:#9ca3af; font-size:14px; margin-top:18px;")
        hint.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(hint)

        self.main_layout.addLayout(layout)
        self.central_widget.setStyleSheet("background:#0f172a;")

    def set_bot_mode(self):
        self.vs_bot = bool(self.bot_checkbox.isChecked())

    def show_shop(self):
        self.state = "shop"
        self.clear_layout()

        back_btn = QPushButton("⬅ Back")
        back_btn.setStyleSheet("background:#4b5563; color:white; padding:10px 16px; border-radius:12px; font-size:16px;")
        back_btn.clicked.connect(self.show_menu)
        self.main_layout.addWidget(back_btn)

        title = QLabel("🛒 WEAPON SHOP")
        title.setStyleSheet("font-size: 40px; font-weight: bold; color: white;")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.main_layout.addWidget(title)

        row = QHBoxLayout()
        row.addWidget(self.shop_panel("Player 1", self.p1))
        row.addWidget(self.shop_panel("Player 2", self.p2))
        self.main_layout.addLayout(row)

        self.central_widget.setStyleSheet("background:#0f172a;")

    def shop_panel(self, name, player: Player):
        panel = QWidget()
        panel.setStyleSheet("background:#111827; border-radius:16px; padding:16px;")
        v = QVBoxLayout(panel)

        t = QLabel(f"{name}  💰 {player.coins}")
        t.setStyleSheet(f"color:{player.color.name()}; font-size:22px; font-weight:bold;")
        v.addWidget(t)

        for k, w in self.weapons.items():
            btn = QPushButton(f"{w.icon} {w.name} ({w.kind})  | DMG {w.damage} | Cost {w.cost}")
            if player.weapon == k:
                btn.setStyleSheet("background:#14532d; color:white; padding:12px; border-radius:12px; font-size:16px;")
            else:
                btn.setStyleSheet("background:#1f2937; color:white; padding:12px; border-radius:12px; font-size:16px;")
            btn.clicked.connect(lambda _, kk=k: self.buy_or_equip(player, kk))
            v.addWidget(btn)

        hint = QLabel("Buy (if needed) then equip.")
        hint.setStyleSheet("color:#9ca3af; font-size:14px;")
        v.addWidget(hint)

        return panel

    def buy_or_equip(self, player: Player, weapon_key: str):
        w = self.weapons[weapon_key]
        if player.weapon == weapon_key:
            return
        if w.cost > 0 and player.coins < w.cost:
            return
        if w.cost > 0:
            player.coins -= w.cost
        player.weapon = weapon_key
        self.show_shop()

    # ---------------- Game ----------------
    def start_game(self):
        self.state = "game"
        self.ticks = 0
        self.keys_pressed.clear()

        self.projectiles.clear()
        self.particles.clear()
        self.pickups.clear()

        for p, x in ((self.p1, 200), (self.p2, W - 200)):
            p.health = 100
            p.x, p.y = x, H / 2
            p.attacking = False
            p.attack_timer = 0
            p.cooldown_timer = 0
            p.hit_flash = 0

        self.clear_layout()

        # Minimal HUD (top strip)
        top = QWidget()
        top.setStyleSheet("background:rgba(17,24,39,200); padding:10px; border-radius:14px;")
        h = QHBoxLayout(top)

        self.p1_health_bar = QProgressBar()
        self.p1_health_bar.setMaximum(100)
        self.p1_health_bar.setValue(100)
        self.p1_health_bar.setStyleSheet("QProgressBar::chunk{background:#22c55e;}")

        self.p2_health_bar = QProgressBar()
        self.p2_health_bar.setMaximum(100)
        self.p2_health_bar.setValue(100)
        self.p2_health_bar.setStyleSheet("QProgressBar::chunk{background:#22c55e;}")

        self.p1_weapon_lbl = QLabel(self.weapon_label(self.p1))
        self.p1_weapon_lbl.setStyleSheet("color:white; font-size:14px;")
        self.p2_weapon_lbl = QLabel(self.weapon_label(self.p2))
        self.p2_weapon_lbl.setStyleSheet("color:white; font-size:14px;")

        left = QVBoxLayout()
        l1 = QLabel("Player 1")
        l1.setStyleSheet("color:#3b82f6; font-weight:bold; font-size:16px;")
        left.addWidget(l1)
        left.addWidget(self.p1_health_bar)
        left.addWidget(self.p1_weapon_lbl)
        h.addLayout(left)

        quit_btn = QPushButton("Quit")
        quit_btn.setStyleSheet("background:#dc2626; color:white; padding:10px 20px; border-radius:12px; font-size:16px;")
        quit_btn.clicked.connect(self.show_menu)
        h.addWidget(quit_btn)

        right = QVBoxLayout()
        r1 = QLabel("Player 2" + (" (BOT)" if self.vs_bot else ""))
        r1.setStyleSheet("color:#ef4444; font-weight:bold; font-size:16px;")
        r1.setAlignment(Qt.AlignmentFlag.AlignRight)
        right.addWidget(r1)
        right.addWidget(self.p2_health_bar)
        self.p2_weapon_lbl.setAlignment(Qt.AlignmentFlag.AlignRight)
        right.addWidget(self.p2_weapon_lbl)
        h.addLayout(right)

        self.main_layout.addWidget(top)

        self.canvas = GameCanvas(self)
        self.main_layout.addWidget(self.canvas)

        bottom = QLabel("P1: WASD + Space | P2: Arrows + Enter | Pickups: coins/potions/weapons spawn.")
        bottom.setStyleSheet("color:#cbd5e1; font-size:14px; padding:8px;")
        bottom.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.main_layout.addWidget(bottom)

        self.central_widget.setStyleSheet("background:#0b1220;")

        # seed some pickups
        for _ in range(4):
            self.spawn_pickup("coin")
        self.spawn_pickup("weapon")
        self.spawn_pickup("potion")

    def weapon_label(self, p: Player):
        w = self.weapons[p.weapon]
        return f"{w.icon} {w.name} ({w.kind})"

    # Qt timer
    def timerEvent(self, event):
        if self.state != "game":
            return
        self.game_loop()

    def game_loop(self):
        self.ticks += 1

        if self.ticks % 160 == 0 and len(self.pickups) < 14:
            roll = random.random()
            if roll < 0.22:
                self.spawn_pickup("weapon")
            elif roll < 0.70:
                self.spawn_pickup("coin")
            else:
                self.spawn_pickup("potion")

        if self.vs_bot:
            self.bot_control_p2()

        self.update_player(self.p1)
        self.update_player(self.p2)
        self.update_projectiles()
        self.update_particles()
        self.collect_pickups()

        # HUD
        self.p1_health_bar.setValue(int(self.p1.health))
        self.p2_health_bar.setValue(int(self.p2.health))
        self.p1_weapon_lbl.setText(self.weapon_label(self.p1))
        self.p2_weapon_lbl.setText(self.weapon_label(self.p2))
        self.canvas.update()

        if self.p1.health <= 0 or self.p2.health <= 0:
            self.show_gameover()

    def update_player(self, p: Player):
        if p.cooldown_timer > 0:
            p.cooldown_timer -= 1
        if p.hit_flash > 0:
            p.hit_flash -= 1

        wpn = self.weapons[p.weapon]
        speed = 6.2 * wpn.speed  # slightly faster in 1080p

        minx = BORDER + PLAYER_RADIUS
        maxx = W - BORDER - PLAYER_RADIUS
        miny = BORDER + PLAYER_RADIUS
        maxy = H - BORDER - PLAYER_RADIUS

        if p.controls['left'] in self.keys_pressed and p.x > minx:
            p.x -= speed
            p.direction = -1
        if p.controls['right'] in self.keys_pressed and p.x < maxx:
            p.x += speed
            p.direction = 1
        if p.controls['up'] in self.keys_pressed and p.y > miny:
            p.y -= speed
        if p.controls['down'] in self.keys_pressed and p.y < maxy:
            p.y += speed

        if p.controls['attack'] in self.keys_pressed and p.cooldown_timer == 0 and not p.attacking:
            self.perform_attack(p)

        if p.attack_timer > 0:
            p.attack_timer -= 1
            if p.attack_timer == 0:
                p.attacking = False

    def perform_attack(self, attacker: Player):
        wpn = self.weapons[attacker.weapon]
        defender = self.p2 if attacker == self.p1 else self.p1

        attacker.cooldown_timer = max(10, int(32 / max(0.25, wpn.speed)))

        if wpn.kind == "melee":
            attacker.attacking = True
            attacker.attack_duration = max(8, int(14 / max(0.35, wpn.speed)))
            attacker.attack_timer = attacker.attack_duration
            self.check_melee_hit(attacker, defender)
        else:
            ang = math.atan2(defender.y - attacker.y, defender.x - attacker.x)
            ang += random.uniform(-wpn.spread, wpn.spread)
            vx = math.cos(ang) * wpn.proj_speed
            vy = math.sin(ang) * wpn.proj_speed
            sx = attacker.x + attacker.direction * 30
            sy = attacker.y

            self.projectiles.append(Projectile(
                x=sx, y=sy, vx=vx, vy=vy,
                dmg=wpn.damage, radius=wpn.proj_radius,
                owner=attacker.pid, life=wpn.proj_life
            ))

            for _ in range(10):
                self.particles.append(Particle(
                    x=sx, y=sy,
                    vx=random.uniform(-1.4, 1.4),
                    vy=random.uniform(-1.4, 1.4),
                    life=random.randint(10, 20),
                    size=random.uniform(2.0, 4.0),
                    color=QColor(251, 191, 36)
                ))

    def check_melee_hit(self, attacker: Player, defender: Player):
        wpn = self.weapons[attacker.weapon]
        dx = defender.x - attacker.x
        dy = defender.y - attacker.y
        dist = math.hypot(dx, dy)
        in_front = (dx * attacker.direction) > -10
        if dist < (wpn.range + 35) and in_front:
            self.damage_player(defender, wpn.damage)

    def damage_player(self, p: Player, dmg: int):
        p.health = max(0, p.health - dmg)
        p.hit_flash = 10
        self.shake = 10
        self.shake_strength = min(12, 3 + dmg // 7)

        for _ in range(18):
            self.particles.append(Particle(
                x=p.x, y=p.y,
                vx=random.uniform(-2.6, 2.6),
                vy=random.uniform(-2.6, 2.6),
                life=random.randint(12, 24),
                size=random.uniform(2.0, 5.0),
                color=QColor(255, 255, 255)
            ))

    def update_projectiles(self):
        if not self.projectiles:
            return

        minx, miny = BORDER, BORDER
        maxx, maxy = W - BORDER, H - BORDER

        new_list = []
        for pr in self.projectiles:
            pr.x += pr.vx
            pr.y += pr.vy
            pr.life -= 1

            self.particles.append(Particle(
                x=pr.x, y=pr.y,
                vx=random.uniform(-0.35, 0.35),
                vy=random.uniform(-0.35, 0.35),
                life=random.randint(8, 14),
                size=random.uniform(1.5, 3.2),
                color=QColor(147, 197, 253) if pr.owner == 1 else QColor(252, 165, 165)
            ))

            if pr.life <= 0:
                continue
            if pr.x < minx or pr.x > maxx or pr.y < miny or pr.y > maxy:
                continue

            target = self.p2 if pr.owner == 1 else self.p1
            if math.hypot(pr.x - target.x, pr.y - target.y) < (pr.radius + PLAYER_RADIUS):
                self.damage_player(target, pr.dmg)
                continue

            new_list.append(pr)

        self.projectiles = new_list

    def update_particles(self):
        if not self.particles:
            return
        newp = []
        for p in self.particles:
            p.x += p.vx
            p.y += p.vy
            p.life -= 1
            if p.life > 0:
                newp.append(p)
        self.particles = newp

    def spawn_pickup(self, kind: str):
        for _ in range(60):
            x = random.randint(BORDER + 80, W - BORDER - 80)
            y = random.randint(BORDER + 120, H - BORDER - 80)

            if math.hypot(x - self.p1.x, y - self.p1.y) < 140:
                continue
            if math.hypot(x - self.p2.x, y - self.p2.y) < 140:
                continue

            if kind == "coin":
                self.pickups.append(Pickup(x=x, y=y, kind="coin", value=25, radius=14))
            elif kind == "potion":
                self.pickups.append(Pickup(x=x, y=y, kind="potion", value=20, radius=16))
            else:
                keys = [k for k in self.weapons.keys() if k != "sword"]
                weapon_key = random.choice(keys)
                self.pickups.append(Pickup(x=x, y=y, kind="weapon", weapon_key=weapon_key, radius=18))
            return

    def collect_pickups(self):
        if not self.pickups:
            return

        remaining = []
        for pu in self.pickups:
            taken = False
            for p in (self.p1, self.p2):
                if math.hypot(pu.x - p.x, pu.y - p.y) < (pu.radius + PLAYER_RADIUS):
                    if pu.kind == "coin":
                        p.coins += pu.value
                    elif pu.kind == "potion":
                        p.health = min(100, p.health + pu.value)
                        for _ in range(12):
                            self.particles.append(Particle(
                                x=p.x, y=p.y,
                                vx=random.uniform(-1.9, 1.9),
                                vy=random.uniform(-1.9, 1.9),
                                life=random.randint(12, 20),
                                size=random.uniform(2.0, 4.0),
                                color=QColor(34, 197, 94)
                            ))
                    elif pu.kind == "weapon":
                        if pu.weapon_key in self.weapons:
                            p.weapon = pu.weapon_key
                            for _ in range(18):
                                self.particles.append(Particle(
                                    x=p.x, y=p.y,
                                    vx=random.uniform(-2.4, 2.4),
                                    vy=random.uniform(-2.4, 2.4),
                                    life=random.randint(12, 22),
                                    size=random.uniform(2.0, 4.5),
                                    color=QColor(251, 191, 36)
                                ))
                    taken = True
                    break
            if not taken:
                remaining.append(pu)

        self.pickups = remaining

    def bot_control_p2(self):
        p = self.p2
        t = self.p1
        w = self.weapons[p.weapon]

        bot_keys = {p.controls['left'], p.controls['right'], p.controls['up'], p.controls['down'], p.controls['attack']}
        self.keys_pressed.difference_update(bot_keys)

        dx = t.x - p.x
        dy = t.y - p.y
        dist = math.hypot(dx, dy)

        if dist > 120:
            if abs(dx) > 14:
                self.keys_pressed.add(p.controls['right'] if dx > 0 else p.controls['left'])
            if abs(dy) > 14:
                self.keys_pressed.add(p.controls['down'] if dy > 0 else p.controls['up'])

        if w.kind == "ranged":
            if 160 < dist < 700 and random.random() < 0.30:
                self.keys_pressed.add(p.controls['attack'])
        else:
            if dist < (w.range + 70) and random.random() < 0.40:
                self.keys_pressed.add(p.controls['attack'])

    def show_gameover(self):
        self.state = "gameover"
        winner = "Player 1" if self.p1.health > 0 else "Player 2"
        winner_obj = self.p1 if self.p1.health > 0 else self.p2
        winner_obj.coins += 120

        self.clear_layout()

        layout = QVBoxLayout()
        layout.setAlignment(Qt.AlignmentFlag.AlignCenter)

        title = QLabel(f"🏆 {winner} WINS! 🏆")
        title.setStyleSheet("font-size: 64px; font-weight: bold; color: white;")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(title)

        reward = QLabel("+120 coins reward!")
        reward.setStyleSheet("font-size: 28px; color: #fbbf24;")
        reward.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(reward)

        again_btn = QPushButton("Play Again")
        again_btn.setStyleSheet("background:#16a34a; color:white; font-size:28px; padding:18px 50px; border-radius:14px;")
        again_btn.clicked.connect(self.start_game)
        layout.addWidget(again_btn)

        menu_btn = QPushButton("Main Menu")
        menu_btn.setStyleSheet("background:#4b5563; color:white; font-size:28px; padding:18px 50px; border-radius:14px;")
        menu_btn.clicked.connect(self.show_menu)
        layout.addWidget(menu_btn)

        self.main_layout.addLayout(layout)
        self.central_widget.setStyleSheet("background:#0f172a;")

    def shake_offset(self):
        if self.shake <= 0:
            return 0.0, 0.0
        self.shake -= 1
        amp = self.shake_strength * (self.shake / 10.0)
        return random.uniform(-amp, amp), random.uniform(-amp, amp)

    # ---------------- Layout utils ----------------
    def clear_layout(self):
        while self.main_layout.count():
            child = self.main_layout.takeAt(0)
            if child.widget():
                child.widget().deleteLater()
            elif child.layout():
                self.clear_sublayout(child.layout())

    def clear_sublayout(self, layout):
        while layout.count():
            child = layout.takeAt(0)
            if child.widget():
                child.widget().deleteLater()
            elif child.layout():
                self.clear_sublayout(child.layout())

    # ---------------- Input ----------------
    def keyPressEvent(self, event):
        # ESC exits fullscreen back to menu
        if event.key() == Qt.Key.Key_Escape:
            self.showNormal()
            self.show_menu()
            return
        self.keys_pressed.add(event.key())

    def keyReleaseEvent(self, event):
        self.keys_pressed.discard(event.key())


if __name__ == "__main__":
    app = QApplication(sys.argv)
    game = BattleArenaGame()
    game.show()  # showFullScreen happens in __init__
    sys.exit(app.exec())
