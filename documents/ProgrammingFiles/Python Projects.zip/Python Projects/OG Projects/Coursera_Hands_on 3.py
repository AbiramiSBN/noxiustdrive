X = ["CB", "AP", "CH", "TI","CC"]


#for item in X:
#    print("I Dont Like...", item)
#count = 0

#while count < len(X):
#    print("I Like...", X[count])
#   count += 1

#for idx, item in enumerate(X):
#  print(idx, item)



