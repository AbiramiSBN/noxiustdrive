x = "SHUTUP"
print(x)