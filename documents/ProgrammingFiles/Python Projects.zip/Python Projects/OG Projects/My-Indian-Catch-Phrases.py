count = 0
while count < 100000:  # Change 1000 to the desired number of repetitions
    print("Amuku Damkuka Amkuku Dumal Attam pota Attam Pota Pakka Pushpa Addadey pushpa enna thotu ey thumbi poda attam pota pakka pushpa adadey", end=" ") 
    count += 1

