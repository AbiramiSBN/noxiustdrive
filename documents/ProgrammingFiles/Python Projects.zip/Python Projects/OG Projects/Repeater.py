count = 0
while count < 1701:  # Change 1000 to the desired number of repetitions
    print("GETABRAIN", end=" ") #Change FEIN to whatever you want
    count += 1
