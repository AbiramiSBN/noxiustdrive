import this
x = "Well This Is Your Motivation"
print(x)